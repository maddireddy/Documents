package com.cloud.SpringCloudLearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudLearningApplication.class, args);
	}

}
