package com.springcrud.springmongocrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongoCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
