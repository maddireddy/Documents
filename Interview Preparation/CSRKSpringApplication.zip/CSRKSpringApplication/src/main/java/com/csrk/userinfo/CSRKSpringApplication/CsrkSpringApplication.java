package com.csrk.userinfo.CSRKSpringApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsrkSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsrkSpringApplication.class, args);
	}

}
