package com.csrk.userinfo.CSRKSpringApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsrkSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
