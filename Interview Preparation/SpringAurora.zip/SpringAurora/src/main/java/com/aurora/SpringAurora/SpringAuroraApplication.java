package com.aurora.SpringAurora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAuroraApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAuroraApplication.class, args);
	}

}
